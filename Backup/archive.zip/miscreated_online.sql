-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 09, 2020 at 05:36 PM
-- Server version: 5.7.27-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `miscreated_online`
--

-- --------------------------------------------------------

--
-- Table structure for table `Characters`
--

CREATE TABLE `Characters` (
  `DBCharacterID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `CharacterID` int(11) NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `AccountID` int(11) NOT NULL,
  `PosX` double NOT NULL,
  `PosY` double NOT NULL,
  `PosZ` double NOT NULL,
  `RotZ` double NOT NULL,
  `Health` double NOT NULL,
  `Food` double NOT NULL,
  `Water` double NOT NULL,
  `Radiation` double NOT NULL,
  `Temperature` double NOT NULL,
  `CreationDate` int(11) NOT NULL,
  `SelectedSlot` text COLLATE utf8_unicode_ci NOT NULL,
  `MapName` text COLLATE utf8_unicode_ci NOT NULL,
  `Gender` int(11) NOT NULL,
  `Data` text COLLATE utf8_unicode_ci NOT NULL,
  `CharacterGUID` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ClanMembers`
--

CREATE TABLE `ClanMembers` (
  `DBClanMemberID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ClanMemberID` int(11) NOT NULL,
  `ClanID` int(11) NOT NULL,
  `AccountID` int(11) NOT NULL,
  `MemberName` text COLLATE utf8_unicode_ci NOT NULL,
  `IsAdmin` int(11) NOT NULL,
  `CanAlterMembers` double NOT NULL,
  `CanAlterParts` double NOT NULL,
  `CanAlterLocks` double NOT NULL,
  `CanAlterPower` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Clans`
--

CREATE TABLE `Clans` (
  `DBClanID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ClanID` int(11) NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `OwnerAccountID` int(11) NOT NULL,
  `ClanName` text COLLATE utf8_unicode_ci NOT NULL,
  `CreationDate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DB_BackupHistory`
--

CREATE TABLE `DB_BackupHistory` (
  `BackupID` int(11) NOT NULL,
  `GUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `BackupDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DB_SteamNames`
--

CREATE TABLE `DB_SteamNames` (
  `SteamID` int(11) NOT NULL,
  `SteamID3` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `LastUpdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `DB_SystemVars`
--

CREATE TABLE `DB_SystemVars` (
  `LastUpdate` datetime NOT NULL,
  `MaintenanceMode` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Entities`
--

CREATE TABLE `Entities` (
  `DBEntityID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `EntityID` int(11) NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `MapName` text COLLATE utf8_unicode_ci NOT NULL,
  `ClassName` text COLLATE utf8_unicode_ci NOT NULL,
  `PosX` double NOT NULL,
  `PosY` double NOT NULL,
  `PosZ` double NOT NULL,
  `RotZ` double NOT NULL,
  `Data` text COLLATE utf8_unicode_ci NOT NULL,
  `EntityGUID` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Items`
--

CREATE TABLE `Items` (
  `DBItemID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ItemID` int(11) NOT NULL,
  `Slot` text COLLATE utf8_unicode_ci NOT NULL,
  `ClassName` text COLLATE utf8_unicode_ci NOT NULL,
  `Data` text COLLATE utf8_unicode_ci NOT NULL,
  `ItemGUID` text COLLATE utf8_unicode_ci NOT NULL,
  `ParentGUID` text COLLATE utf8_unicode_ci NOT NULL,
  `OwnerGUID` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ServerAccountData`
--

CREATE TABLE `ServerAccountData` (
  `DBServerAccountDataID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `ServerAccountDataID` int(11) NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `AccountID` int(11) NOT NULL,
  `Guide00` int(11) NOT NULL,
  `Guide01` int(11) NOT NULL,
  `Guide02` int(11) NOT NULL,
  `Guide03` int(11) NOT NULL,
  `ClanID` int(11) NOT NULL,
  `IsPendingClanInvite` int(11) NOT NULL,
  `IgnoreClanInvites` int(11) NOT NULL,
  `HadTasksAssigned` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sqlite_sequence`
--

CREATE TABLE `sqlite_sequence` (
  `DBsqlite_sequenceID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `seq` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `StructureParts`
--

CREATE TABLE `StructureParts` (
  `DBStructurePartID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `StructurePartID` int(11) NOT NULL,
  `PartTypeID` int(11) NOT NULL,
  `PosX` double NOT NULL,
  `PosY` double NOT NULL,
  `PosZ` double NOT NULL,
  `RotZ` double NOT NULL,
  `StructurePartGUID` text COLLATE utf8_unicode_ci NOT NULL,
  `Data` text COLLATE utf8_unicode_ci NOT NULL,
  `StructureGUID` text COLLATE utf8_unicode_ci NOT NULL,
  `ParentStructurePartGUIDs` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Structures`
--

CREATE TABLE `Structures` (
  `DBStructuresID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `StructureID` int(11) NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `MapName` text COLLATE utf8_unicode_ci NOT NULL,
  `AccountID` int(11) NOT NULL,
  `ClassName` text COLLATE utf8_unicode_ci NOT NULL,
  `PosX` double NOT NULL,
  `PosY` double NOT NULL,
  `PosZ` double NOT NULL,
  `RotX` double NOT NULL,
  `RotY` double NOT NULL,
  `RotZ` double NOT NULL,
  `AbandonTimer` int(11) NOT NULL,
  `Data` text COLLATE utf8_unicode_ci NOT NULL,
  `StructureGUID` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Tasks`
--

CREATE TABLE `Tasks` (
  `DBTaskID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `AccountID` int(11) NOT NULL,
  `TaskCRC` int(11) NOT NULL,
  `TaskType` int(11) NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Vehicles`
--

CREATE TABLE `Vehicles` (
  `DBVehicleID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `GameServerID` int(11) NOT NULL,
  `MapName` text COLLATE utf8_unicode_ci NOT NULL,
  `Category` text COLLATE utf8_unicode_ci NOT NULL,
  `ClassName` text COLLATE utf8_unicode_ci NOT NULL,
  `PosX` double NOT NULL,
  `PosY` double NOT NULL,
  `PosZ` double NOT NULL,
  `RotX` double NOT NULL,
  `RotY` double NOT NULL,
  `RotZ` double NOT NULL,
  `AbandonTimer` int(11) NOT NULL,
  `Data` text COLLATE utf8_unicode_ci NOT NULL,
  `VehicleGUID` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Version`
--

CREATE TABLE `Version` (
  `DBVersionID` int(11) NOT NULL,
  `DBBackupGUID` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `Version` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Characters`
--
ALTER TABLE `Characters`
  ADD UNIQUE KEY `DBCharacterID` (`DBCharacterID`);

--
-- Indexes for table `ClanMembers`
--
ALTER TABLE `ClanMembers`
  ADD PRIMARY KEY (`DBClanMemberID`);

--
-- Indexes for table `Clans`
--
ALTER TABLE `Clans`
  ADD PRIMARY KEY (`DBClanID`);

--
-- Indexes for table `DB_BackupHistory`
--
ALTER TABLE `DB_BackupHistory`
  ADD PRIMARY KEY (`BackupID`);

--
-- Indexes for table `DB_SteamNames`
--
ALTER TABLE `DB_SteamNames`
  ADD PRIMARY KEY (`SteamID`);

--
-- Indexes for table `Entities`
--
ALTER TABLE `Entities`
  ADD PRIMARY KEY (`DBEntityID`);

--
-- Indexes for table `Items`
--
ALTER TABLE `Items`
  ADD PRIMARY KEY (`DBItemID`);

--
-- Indexes for table `ServerAccountData`
--
ALTER TABLE `ServerAccountData`
  ADD PRIMARY KEY (`DBServerAccountDataID`);

--
-- Indexes for table `sqlite_sequence`
--
ALTER TABLE `sqlite_sequence`
  ADD PRIMARY KEY (`DBsqlite_sequenceID`);

--
-- Indexes for table `StructureParts`
--
ALTER TABLE `StructureParts`
  ADD PRIMARY KEY (`DBStructurePartID`);

--
-- Indexes for table `Structures`
--
ALTER TABLE `Structures`
  ADD PRIMARY KEY (`DBStructuresID`);

--
-- Indexes for table `Tasks`
--
ALTER TABLE `Tasks`
  ADD PRIMARY KEY (`DBTaskID`);

--
-- Indexes for table `Vehicles`
--
ALTER TABLE `Vehicles`
  ADD PRIMARY KEY (`DBVehicleID`);

--
-- Indexes for table `Version`
--
ALTER TABLE `Version`
  ADD PRIMARY KEY (`DBVersionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Characters`
--
ALTER TABLE `Characters`
  MODIFY `DBCharacterID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ClanMembers`
--
ALTER TABLE `ClanMembers`
  MODIFY `DBClanMemberID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Clans`
--
ALTER TABLE `Clans`
  MODIFY `DBClanID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Entities`
--
ALTER TABLE `Entities`
  MODIFY `DBEntityID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Items`
--
ALTER TABLE `Items`
  MODIFY `DBItemID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ServerAccountData`
--
ALTER TABLE `ServerAccountData`
  MODIFY `DBServerAccountDataID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sqlite_sequence`
--
ALTER TABLE `sqlite_sequence`
  MODIFY `DBsqlite_sequenceID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `StructureParts`
--
ALTER TABLE `StructureParts`
  MODIFY `DBStructurePartID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Structures`
--
ALTER TABLE `Structures`
  MODIFY `DBStructuresID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Tasks`
--
ALTER TABLE `Tasks`
  MODIFY `DBTaskID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Vehicles`
--
ALTER TABLE `Vehicles`
  MODIFY `DBVehicleID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Version`
--
ALTER TABLE `Version`
  MODIFY `DBVersionID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;
