<?php
	include("class.SFTP.php");
	$backupHome = "/home/phunter/MiscreatedBackups";

	//Create Server Folder
	if (!is_dir("$backupHome/107.150.28.52")) {
		mkdir("$backupHome/107.150.28.52");
	}
	chdir("$backupHome/107.150.28.52");

	//Create Date Folder
	$date = new DateTime();
	$dateFormat = $date->format('Y-m-d');
	if (!is_dir($dateFormat)) {
		mkdir($dateFormat);
	}
	chdir($dateFormat);

	//Go Get It
	$ftp = new SFTP('107.150.28.52', 'Pghpunkid', 'R0ttenAppl3$!', 8821);
	if (!$ftp->connect()) {
		echo "Failed to connect to FTP Server.";
	}

	$ftp->get("107.150.28.52_64000/miscreated.db","miscreated.db",FTP_BINARY);
	$ftp->get("107.150.28.52_64000/hosting.cfg","hosting.cfg",FTP_BINARY);
	//sync(".");
	$ftp->close();

	chdir("$backupHome/107.150.28.52/");
	$dateFormatZip = $date->format('Y-m-d_Hi');
	$tar = 'tar -cvf "'.$dateFormatZip.'.tar" '.$dateFormat;
	shell_exec($tar);
	shell_exec("cp $dateFormat/miscreated.db $backupHome/107.150.28.52/current/");
	shell_exec("rm -fr $dateFormat/");

	function sync($path) {
		global $ftp;

		$ftp->cd($path);
		chdir($path);

		$list = $ftp->ls(".");
		$pwd = $ftp->pwd();

		for ($l=0; $l<sizeof($list); $l++) {
			$file = $list[$l];

			if ($file != "." && $file != "..") {
				if (!file_exists($file)) {
					$isDir = $ftp->isdir("$pwd/$file");
					if ($isDir) {
						mkdir($file);
						echo "$pwd/$file\n";
						sync($file);
					}
					else {
						echo "$pwd/$file\n";
						$ftp->get($file,$file,FTP_BINARY);
					}
				}
			}
		}
		chdir("..");
		$ftp->cd("..");
	}
?>
